﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ПР_09_БД
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connect = "host=localhost;uid=root;pwd=;database=db49";

            MySqlConnection conn = new MySqlConnection(connect);

            conn.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM Conductor;", conn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            dataGridView1.DataSource = dt;

            conn.Close();
        }

        private void button1_click(object sender, EventArgs e)
        {
            try
            {
                string connect = "host=localhost;uid=root;pwd=;database=db49";

                MySqlConnection conn = new MySqlConnection(connect);

                conn.Open();

                string insertcmd = $"INSERT INTO Conductor(tab_number, FullName, BirthDate, Phone, Email) VALUE ('{tabnumber.Text}','{fullname.Text}','{birthday.Text}','{phone.Text}','{email.Text}');";

                MySqlCommand cmd = new MySqlCommand(insertcmd, conn);

                cmd.ExecuteNonQuery();

                tabnumber.Text = "";
                fullname.Text = "";
                birthday.Text = "";
                phone.Text = "";
                email.Text = "";

                MySqlCommand cmd2 = new MySqlCommand("SELECT * FROM Conductor;", conn);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd2);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dataGridView1.DataSource = dt;

                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
