SELECT title
FROM books
WHERE copies_available < 5