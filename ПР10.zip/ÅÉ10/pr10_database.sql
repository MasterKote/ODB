CREATE TABLE Authors (
author_id SERIAL PRIMARY KEY NOT NULL,
full_name VARCHAR(255) NOT NULL);

CREATE TABLE Books (
book_id SERIAL PRIMARY KEY NOT NULL,
title VARCHAR(255) NOT NULL,
author_id INT NOT NULL,
publication_year INT,
price DECIMAL(10,2),
copies_available INT,
withdrawal_mark BOOLEAN DEFAULT FALSE,
FOREIGN KEY (author_id) REFERENCES Authors(author_id));

CREATE TABLE Readers (
reader_id SERIAL PRIMARY KEY NOT NULL,
full_name VARCHAR(255) NOT NULL,
address VARCHAR(255),
phone VARCHAR (50),
library_card_number VARCHAR (255) UNIQUE);

CREATE TABLE BookLoans (
load_id SERIAL PRIMARY KEY NOT NULL,
book_id INT,
reader_id INT,
issue_date DATE NOT NULL,
planned_return_date DATE NOT NULL,
actual_return_date DATE,
FOREIGN KEY (book_id) REFERENCES Books(book_id),
FOREIGN KEY (reader_id) REFERENCES Readers(reader_id))