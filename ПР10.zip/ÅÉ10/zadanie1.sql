SELECT full_name, address, phone, library_card_number
FROM readers
ORDER BY full_name ASC