SELECT title, price
FROM books
ORDER BY price DESC
LIMIT 1